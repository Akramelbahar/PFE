<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Conge MS</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/main.css">
    <style>
        .logo-container {
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 20px;
        }

        .logo-container img {
            max-width: 150px; 
            height: auto;
        }
    </style>
</head>
<body class="purple-color">
<div class="container">
        
        <div class="row justify-content-center">
            <div class="col-xl-10 col-lg-12 col-md-9">
                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <div class="row">
                            <div class="col-lg-4 logo-container">
                                <img src="img/image.png" alt="Logo" class="img-fluid">
                            </div>
                            <div class="col-lg-8">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h1 class="h4 text-gray-900 mb-4">Conge MS - Login</h1>
                                    </div>
                                    <form class="user" method="post" action="auth.php">
                                        <div class="form-group">
                                            <input type="text" class="form-control form-control-user" name="username" id="username" placeholder="Enter your username...">
                                        </div>
                                        <div class="form-group">
                                            <input type="password" class="form-control form-control-user" name="password" id="password" placeholder="Password">
                                        </div>
                                        <div class="erreur">
                                            <?php
                                            if (isset($_GET['err'])) {
                                                if ($_GET['err'] == 1) {
                                                    echo "Veuillez saisir un login correct.";
                                                } else {
                                                    echo "Le mot de passe ne correspond pas au login saisi.";
                                                }
                                            }
                                            ?>
                                        </div>
                                        <div class="form-group">
                                            <div class="custom-control custom-checkbox small">
                                                <input type="checkbox" class="custom-control-input" id="customCheck">
                                                <label class="custom-control-label" for="customCheck">Remember Me</label>
                                            </div>
                                        </div>
                                        <button type="submit" class="btn btn-primary btn-user btn-block purple-color">
                                            Login
                                        </button>
                                    </form>
                                    <hr>
                                    <div class="text-center">                             
                                    </div>
                                    <div class="text-center">
                                        <a id="col" class="small" href="NewAcc.php">Create an Account!</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>