<?php
require_once 'dbaccess.php';
$db = new Dbaccess();

if (isset($_POST['registre'])) {
    $firstname = $_POST['fname'];
    $lastname = $_POST['lname'];
    $username = $_POST['user'];
    $password = $_POST['pass'];

    $checkUser = "SELECT * FROM user WHERE username = '$username'";
    $db->query($checkUser);

    $result = $db->resultSet();

    if ($db->rowCount() > 0) {
        echo "Username already exists!!";
    } else {
        $insertQuery = "INSERT INTO user (username, firstname, lastname, password) VALUES ('$username', '$firstname', '$lastname', '$password')";
        $db->query($insertQuery);

        if ($db->execute()) {
            session_start();
            $_SESSION['username'] = $username;
            $_SESSION['firstname'] = $firstname;
            $_SESSION['lastname'] = $lastname;

            $userIdQuery = "SELECT id FROM user WHERE username = '$username'";
            $db->query($userIdQuery);
            $user = $db->single();
            $_SESSION['iduser'] = $user->id;
            header('Location: home.php');
            exit(); 
        } else {
            echo "Error occurred while inserting data.";
        }
    }

}
?>
