<?php
require_once 'session.php';
require_once('EmployeeClass.php');
require_once('CongeTypeClass.php');


$employee = new Employee();
$lstemp = $employee->findAll();

$ct = new CongeType();
$lstct = $ct->findAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>New conge</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/main.css">
</head>
<body id="page-top">
    <div id="wrapper">
        <ul class="navbar-nav purple-color sidebar sidebar-dark accordion" id="accordionSidebar">

            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="#">

                <div class="sidebar-brand-text mx-3">Conge MS<sup>1.0</sup></div>
            </a>
            <hr class="sidebar-divider my-0">
            <li class="nav-item active">
                <a class="nav-link" href="home.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Home</span></a>
            </li>
            <hr class="sidebar-divider">
            <li class="nav-item">
                <a class="nav-link" href="employeeList.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Employees</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="departementList.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Departements</span></a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="congeList.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Conges</span></a>
            </li>

            <li class="nav-item">
                <a class="nav-link" href="congeTypeList.php">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Conge types</span></a>
            </li>
            <hr class="sidebar-divider d-none d-md-block">

            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>
        </ul>
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                    <ul class="navbar-nav ml-auto">
                        <div class="topbar-divider d-none d-sm-block"></div>
                        <li class="nav-item dropdown no-arrow">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <span class="mr-2 d-none d-lg-inline text-gray-600 small"><?php echo $_SESSION['firstname'] . ' ' . $_SESSION['lastname'] ?></span>
                                <img class="img-profile rounded-circle" src="img/undraw_profile.svg">
                            </a>
                            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">

                                <a class="dropdown-item" href="logout.php">
                                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                                    Logout
                                </a>
                            </div>
                        </li>
                    </ul>
                </nav>
                <div class="container-fluid px-5 pt-3">
                    <h1 class="h3 mb-4 text-gray-800">New conge</h1>
                    <form class="user" method="post" action="congeSave.php">
                        <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <input type="date" class="form-control form-control-user" id="exampleFirstName" placeholder="Date" name="date">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <input type="date" class="form-control form-control-user" id="exampleFirstName" placeholder="Starts at" name="starts-at">
                            </div>
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <input type="date" class="form-control form-control-user" id="exampleFirstName" placeholder="ends at" name="ends-at">
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <select name="status" id="status" class="form-control">
                                    <option value="" selected hidden disabled>--Status--</option>
                                    <option value="Pending">Pending</option>
                                    <option value="Rejected">Rejected</option>
                                    <option value="Allowed">Allowed</option>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <select name="employee" id="employee" class="form-control">
                                    <option value="" selected disabled hidden>--Employee--</option>
                                    <?php
                                    foreach ($lstemp as $c) {
                                        echo '<option value="' . $c->id_emp . '">' . $c->firstname . ' ' . $c->lastname . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                            <div class="col-sm-6">
                                <select name="conge-type" id="conge-type" class="form-control ">
                                    <option value="" selected disabled hidden>--Conge type--</option>
                                    <?php
                                    foreach ($lstct as $c) {
                                        echo '<option value="' . $c->id . '">' . $c->type_name . '</option>';
                                    }
                                    ?>
                                </select>
                            </div>
                        </div>
                        <div class="form-group row">
                            <div class="col-sm-6 mb-3 mb-sm-0">
                                <button type="submit" value="" class="btn btn-primary purple-color btn-user btn-block col-sm-6 mb-3 mb-sm-0" name="save-conge">Save</button>
                            </div>
                        </div>
                        <hr>
                    </form>
                </div>
            </div>
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Conge MS 1.0 AMINE</span>
                    </div>
                </div>
            </footer>
        </div>
    </div>
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>
</body>
</html>