<?php

class Dbaccess
{
    private $_dbHost = 'localhost';
    private $_dbUser = 'root';
    private $_dbPass = 'amine2004';
    private $_dbName = 'congedb';
    private $_statement;
    private $_dbHandler;
    private $_error;
    public function __construct()
    {
        $conn = 'mysql:host=' . $this->_dbHost . ';dbname=' . $this->_dbName . ';port=3306';
        try {
            $this->_dbHandler = new PDO($conn, $this->_dbUser, $this->_dbPass);
        } catch (PDOException $e) {
            $this->_error = $e->getMessage();
            echo $this->_error;
        }
    }
    public function query($sql)
    {
        $this->_statement = $this->_dbHandler->prepare($sql);
    }
    public function execute()
    {
        return $this->_statement->execute();
    }
    public function resultSet()
    {
        $this->execute();
        return $this->_statement->fetchAll(PDO::FETCH_OBJ);
    }
    public function single()
    {
        $this->execute();
        return $this->_statement->fetch(PDO::FETCH_OBJ);
    }
    public function rowCount()
    {
        return $this->_statement->rowCount();
    }
}
